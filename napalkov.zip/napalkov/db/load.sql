BEGIN;
DELETE FROM readings;
DELETE FROM events;
DELETE FROM sqlite_sequence WHERE name IN ('readings','events');
INSERT INTO readings(n,t_s,sensor,value) VALUES(1,1,'s1',999);
INSERT INTO events(n,t_s,type,message) VALUES(1,1,'FAULT','датчик s1 вне диапазона');
INSERT INTO readings(n,t_s,sensor,value) VALUES(1,1,'s2',25);
INSERT INTO readings(n,t_s,sensor,value) VALUES(1,1,'s3',50);
COMMIT;
